<?php 
session_start();

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "details_inventory_management";

// Create connection
$connection = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection Failed: " . $connection->connect_error);
}

// Function to process purchase using FIFO
function processPurchase($productName, $quantity) {
    global $connection; // Use the global connection variable

    // Fetch all available items for the product in FIFO order
    $product_query = "SELECT * FROM product_management WHERE product_name = ? AND quantity > 0 ORDER BY date_added ASC";
    $stmt = $connection->prepare($product_query);
    $stmt->bind_param("s", $productName);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc() && $quantity > 0) {
        $available_quantity = $row['quantity'];

        if ($available_quantity > 0) {
            // Determine how much to deduct
            $deduct_quantity = min($available_quantity, $quantity);

            // Update the quantity in the database
            $new_quantity = $available_quantity - $deduct_quantity;
            $update_query = "UPDATE product_management SET quantity = ? WHERE id = ?";
            $update_stmt = $connection->prepare($update_query);
            $update_stmt->bind_param("ii", $new_quantity, $row['id']);
            $update_stmt->execute();

            // Deduct the quantity
            $quantity -= $deduct_quantity;
        }
    }

    if ($quantity > 0) {
        echo "Not enough stock available for product: " . htmlspecialchars($productName);
    } else {
        echo "Purchase successful for product: " . htmlspecialchars($productName);
    }

    $stmt->close();
}

// Handle purchase submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productName = $_POST['product_name']; // Get the product name from the form
    $quantity = (int)$_POST['quantity']; // Get the quantity from the form
    processPurchase($productName, $quantity);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h1 class="mt-4">Inventory Management</h1>

    <!-- Purchase Form -->
    <form method="POST" action="" class="mt-4 mb-4">
        <div class="form-group">
            <input type="text" name="product_name" class="form-control" placeholder="Product Name" required>
        </div>
        <div class="form-group">
            <input type="number" name="quantity" class="form-control" placeholder="Quantity" required min="1">
        </div>
        <button type="submit" class="btn btn-primary">Purchase</button>
    </form>

    <div class="card">
        <div class="card-body">
            <div style="max-height: 400px; overflow-y: scroll;">
                <table class="table table-striped table-bordered" id="data">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Category</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Price</th>
                            <th scope="col">Date Added</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $fetch_query = "SELECT * FROM product_management ORDER BY date_added ASC";
                            $fetch_query_run = mysqli_query($connection, $fetch_query);

                            if (mysqli_num_rows($fetch_query_run) > 0) {
                                while ($row = mysqli_fetch_array($fetch_query_run)) {
                                    ?>
                                    <tr>
                                        <td class="product_id"><?php echo htmlspecialchars($row['id']); ?></td>
                                        <td class="account_name"><?php echo htmlspecialchars($row['product_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                                        <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                        <td><?php echo htmlspecialchars($row['price']); ?></td>
                                        <td><?php echo htmlspecialchars($row['date_added']); ?></td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="6" class="text-center">No record found</td>
                                </tr>
                                <?php
                            }
                            $connection->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
