<?php 
session_start();
include('account_management_header.php');

?>  
<link rel="stylesheet" href="code.css">
<div class="modal fade" id="insertdata" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="insertdataLabel" aria-hidden="true">
  	<div class="modal-dialog">
    	<div class="modal-content">
     		<div class="modal-header">
        		<h1 class="modal-title fs-5" id="insertdataLabel">Add Account</h1>
        		<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      		</div>
	      	<form action="account_management_function.php" method="POST">
		      	<div class="modal-body">
			      	<div class="form-group ">
			      		<label for="">Full Name</label>
			                <input type = "text" name="full_name" class="form-control" placeholder="Enter Name">
			      	</div>

			      	<div class="form-group ">
			            <label for="">Username</label>
			                <input type = "text" name="username" class="form-control" placeholder="Enter Username">
			        </div>

			        <div class="form-group ">
			            <label for="">Email</label>
			                <input type = "email" name="email" class="form-control" placeholder="Enter Email">
			        </div>

			        <div class="form-group ">
			            <label for="">Password</label>
			                <input type = "password" name="password" class="form-control" placeholder="Enter Password">
			        </div>
		      	</div>
			      	<div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				        <button type="submit" name="save_data" class="btn btn-primary">Save Data</button>
			      	</div>
	  		</form>
    	</div>
  	</div>
</div>

<div class="modal fade" id="viewaccountdata" tabindex="-1" aria-labelledby="viewaccountdataLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="viewaccountdataLabel">View Account</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        	<div class="view_account_data"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="editdata" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editdataLabel" aria-hidden="true">
  	<div class="modal-dialog">
    	<div class="modal-content">
     		<div class="modal-header">
        		<h1 class="modal-title fs-5" id="editdataLabel">Edit $full_name  Account</h1>
        		<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      		</div>
	      	<form action="account_management_function.php" method="POST">
		      	<div class="modal-body">

		      		<div class="form-group ">
			 
			                <input type = "hidden" name="id" class="form-control" id='account_id'>
			      	</div>

			      	<div class="form-group ">
			      		<label for="">Full Name</label>
			                <input type = "text" name="full_name" class="form-control" id='full_name' placeholder="Enter Name">
			      	</div>

			      	<div class="form-group ">
			            <label for="">Username</label>
			                <input type = "text" name="username" class="form-control" id='username' placeholder="Enter Username">
			        </div>

			        <div class="form-group ">
			            <label for="">Email</label>
			                <input type = "email" name="email" class="form-control" id='email' placeholder="Enter Email">
			        </div>
		      	</div>
			      	<div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
				        <button type="submit" name="update_data" class="btn btn-primary">Update Data</button>
			      	</div>
	  		</form>
    	</div>
  	</div>
</div>


			<div class="container mt-5">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<?php
			 	if (isset($_SESSION['status']) && $_SESSION['status'] != '')
			 	{

			 	?>
					<div class="alert alert-warning alert-dismissible fade show" role="alert">
  						<strong>Hey !</strong> <?php echo $_SESSION['status']; ?>
  						<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
					</div>
				<?php
			 		unset($_SESSION['status']);
			 	}
				?>
			<div class="card">
				<div class="card-header">
					<h4>POP UP MODAL</h4>
						<button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#insertdata ">
  							Add Account
						</button>
				</div>
					<div class="card-body">
						<div style="max-height: 400px; overflow-y: scroll;">

							<div class="search-sort-container">
            					<div class="search">
               					 <i class='bx bx-search-alt-2'></i>
               						 <input id="search" type="text" name="search" placeholder="Search" class="form-control">
            			</div>




						<table class="table table-striped table-bordered table-sortable" id="data">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Username</th>
            <th scope="col">Email</th>
            <th scope="col">View Data</th>
            <th scope="col">Action</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "inventory_management";

            $connection = new mysqli($servername, $username, $password, $dbname);

            if ($connection->connect_error) {
                die("Connection Failed: " . $connection->connect_error);
            }

            $fetch_query = "SELECT * FROM account_management";
            $fetch_query_run = mysqli_query($connection, $fetch_query);

            if (mysqli_num_rows($fetch_query_run) > 0) {
                while ($row = mysqli_fetch_array($fetch_query_run)) {
                    ?>
                    <tr>
                        <td class="account_id"><?php echo htmlspecialchars($row['id']); ?></td>
                        <td class="account_name"><?php echo htmlspecialchars($row['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td>
                            <a href="#" class="btn btn-info btn-sm view_data">View Data</a>
                        </td>
                        <td>
                            <a href="#" class="btn btn-info btn-sm edit_data"><i class='bx bx-edit-alt'></i></a>
                        </td>
                        <td>
                            <a href="#" class="btn btn-info btn-sm delete_button">Remove</a>
                        </td>
                    </tr>
                    <?php
                }
            } else {
                ?>
                <tr>
                    <td colspan="7" class="text-center">No record found</td>
                </tr>
                <?php
            }
            $connection->close();
        ?>
    </tbody>
</table>








					</div>
					</div>
			</div>
		</div>
	</div>
</div>


<?php include('account_management_footer.php');?>

<script>
	
$(document).ready(function(){
	$('.view_data').click(function (e){
		e.preventDefault();

		var account_id = $(this).closest('tr').find('.account_id').text();

	$.ajax({
		method: "POST",
		url: "account_management_function.php",
		data: {
			'click_view_btn':true,
			'account_id': account_id,
		},
		success: function (response){
			
			$('.view_account_data').html(response);
			$('#viewaccountdata').modal('show');
		}
	});
	});
});




$(document).ready(function(){
	$('.edit_data').click(function (e){
		e.preventDefault();

		var account_id = $(this).closest('tr').find('.account_id').text();
		
	
		

	$.ajax({
		method: "POST",
		url: "account_management_function.php",
		data: {
			'click_edit_btn':true,
			'account_id': account_id,
		},
		success: function (response){

			$.each(response, function(key, value){
				$('#account_id').val(value['id']);
				$('#full_name').val(value['full_name']);
				$('#username').val(value['username']);
				$('#email').val(value['email']);
			});
			
		$('#editdata').modal('show');
		}
	});
	});
});




$(document).ready(function(){
	$('.delete_button').click(function (e){
		e.preventDefault();

	
		
	var account_id = $(this).closest('tr').find('.account_id').text();
		
		$.ajax({
		method: "POST",
		url: "account_management_function.php",
		data: {
			'click_delete_btn':true,
			'account_id': account_id,
		},
		success: function (response){

			
				console.log(response);
				window.location.reload();
				
			
		}	
		
		
	});

	});
});


$(document).ready(function(){
	$('#search').keyup(function (){
		search_table($(this).val());
	});
	function search_table(value){
		$('#data tr').each(function(){
			var found ='false';
			$(this).each(function(){
				if($(this).text().toLowerCase().indexOf(value.toLowerCase())>=0)
				{
						found ='true';
				}

			});
			if(found=='true'){
				$(this).show();
			}else{
				$(this).hide();
			}
			

			
		});
	}
});

function sortTableByColumn(table, column, asc = true) {
    const dirModifier = asc ? 1 : -1;
    const tBody = table.tBodies[0];
    const rows = Array.from(tBody.querySelectorAll("tr"));

    // Sort each row
    const sortedRows = rows.sort((a, b) => {
        const aColText = a.querySelector(`td:nth-child(${column + 1})`).textContent.trim().toLowerCase();  // Convert to lowercase
        const bColText = b.querySelector(`td:nth-child(${column + 1})`).textContent.trim().toLowerCase();  // Convert to lowercase

        // Check if the column is numeric, and sort numerically if so
        const aColValue = isNaN(aColText) ? aColText : parseFloat(aColText);
        const bColValue = isNaN(bColText) ? bColText : parseFloat(bColText);

        return aColValue > bColValue ? (1 * dirModifier) : (-1 * dirModifier);
    });

    // Remove all existing rows from the table
    while (tBody.firstChild) {
        tBody.removeChild(tBody.firstChild);
    }

    // Re-add the newly sorted rows
    tBody.append(...sortedRows);

    // Remove sorting classes from all headers
    table.querySelectorAll("th").forEach(th => th.classList.remove("th-sort-asc", "th-sort-desc"));

    // Add the appropriate sorting class to the clicked header
    table.querySelector(`th:nth-child(${column + 1})`).classList.toggle("th-sort-asc", asc);
    table.querySelector(`th:nth-child(${column + 1})`).classList.toggle("th-sort-desc", !asc);
}

// Attach click event listeners to each table header cell
document.querySelectorAll(".table-sortable th").forEach(headerCell => {
    headerCell.addEventListener("click", () => {
        const tableElement = headerCell.closest("table");
        const headerIndex = Array.prototype.indexOf.call(headerCell.parentElement.children, headerCell);
        const currentIsAscending = headerCell.classList.contains("th-sort-asc");

        // Sort the table by the clicked column
        sortTableByColumn(tableElement, headerIndex, !currentIsAscending);
    });
});

</script>
