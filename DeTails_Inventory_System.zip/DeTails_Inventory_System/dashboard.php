<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="dashboard.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Dashboard</title>
</head>
<body>
    <nav class="sidebar close">
        <header>
            <div class="image-text">
                <span class="image">
                    <img src="shop_logo.png" alt="logo">
                </span>
                <div class="text header-text">
                    <span class="name">Inventory System</span>
                    <span class="profession">DeTails Pet Essentials</span>
                </div>
            </div>
            <i class='bx bx-chevron-right toggle'></i>
        </header>
        <div class="menu-bar">
            <div class="menu">
                <ul class="menu-links">
                    <li class="nav-link">
                        <a href="?page=dashboard">
                            <i class='bx bx-home icon'></i>
                            <span class="text nav-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="?page=account">
                            <i class='bx bxs-user-account icon'></i>
                            <span class="text nav-text">Accounts</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="?page=product_list">
                            <i class='bx bx-category icon'></i>
                            <span class="text nav-text">Product List</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="?page=stocks">
                            <i class='bx bx-list-ul icon'></i>
                            <span class="text nav-text">Stocks</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="?page=purchase">
                            <i class='bx bxs-package icon'></i>
                            <span class="text nav-text">Purchase</span>
                        </a>
                    </li>
                    <li class="nav-link">
                        <a href="?page=sales_report">
                            <i class='bx bxs-report icon'></i>
                            <span class="text nav-text">Sales Report</span>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="bottom-content">
    <li class="">
        <a href="#" onclick="window.location.href='logout.php'">
            <i class='bx bx-log-out icon'></i>
            <span class="text nav-text">Logout</span>
        </a>
    </li>
</div>
        </div>
    </nav>

        <section class="home">
        <?php
        // Set default page
        $page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

        // Include the corresponding page content
        switch ($page) {
            case 'account':
                include 'account_management.php';
                break;
            case 'product_list':
                include 'product_management.php';
                break;
            case 'stocks':
                include 'stocks_management.php';
                break;
            case 'purchase':
                include 'products.php';
                break;
            case 'sales_report':
                include 'stocks.php';
                break;
            default:
                include 'dashboard_content.php'; // Default content for dashboard
        }
        ?>
    </section>
   

 

    <script src="dashboard.js"></script>
</body>
</html>