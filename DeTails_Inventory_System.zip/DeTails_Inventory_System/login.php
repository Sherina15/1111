<?php
	session_start();

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "inventory_management";

	$connection = new mysqli($servername, $username, $password, $dbname);

	if($connection->connect_error)
	{
		die("Connection Failed: " . $connection->connect_error);
	}

	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		$username = $_POST['username'];
		$password = $_POST['password'];

		$query = "SELECT * FROM account_management WHERE username = '$username'";
		$result = $connection->query($query);

		if ($result->num_rows > 0) 
		{
			$row = $result -> fetch_assoc();

			if (password_verify($password, $row['password']))
			{
				$_SESSION['username'] = $username;
				header('Location: dashboard.php');
			}
			else
			{
				echo "Invalid password";
			}	
		}
		else
		{
			echo "No user Found";
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
</head>
<body>
	<form method="POST" action="">
		<label>Username</label>
		<input type="text" name="Username" placeholder="Enter Name" required>

		<label>Password</label>
		<input type="password" name="password" placeholder="Enter Password" required>

		<button type="submit" value="login">		
	</form>
</body>
</html>