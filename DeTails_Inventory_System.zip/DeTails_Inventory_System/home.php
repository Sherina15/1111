<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>
	<link rel = "stylesheet" href="home.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>

<header>
  	<a href="#" class="logo">Inventory Management System</a>
  		<nav>
		    <a href="#home" class="active">Home</a>
		    <a href="#about">About</a>
		    <a href="#services">Services</a>
		    <a href="#footer">Contact</a>
    		<ul>
      			<li><button><a href = "login.php">Sign In</a></button></li>
    		</ul>
  		</nav>
</header>
			<section id="home">Home</section>
			<section id="about">About</section>
			<section id="services">Services</section>

			<script src="dashboard.js"></script>


	<div class="content-items">
		<image src>	
	</div>

	<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="footer-col">
					<h4>Company</h4>
					<ul>
						<li><a href ="#">about us</a></li>
						<li><a href ="#">Our Services</a></li>
						<li><a href ="#">Privacy and Policy</a></li>
						<li><a href ="#">about us</a></li>
					</ul>
				</div>
				<div class="footer-col">
					<h4>Get help</h4>
					<ul>
						<li><a href ="#">about us</a></li>
						<li><a href ="#">Our Services</a></li>
						<li><a href ="#">Privacy and Policy</a></li>
					</ul>
				</div>
				<div class="footer-col">
					<h4>Online shop</h4>
					<ul>
						<li><a href ="#">about us</a></li>
						<li><a href ="#">Our Services</a></li>
						<li><a href ="#">Privacy and Policy</a></li>
					</ul>
				</div>
				<div class="footer-col">
					<h4>Follow us</h4>
					<div class="social-links">
						<a href ="#"><i class="fab fa-facebook-f"></i></a>
						<a href ="#"><i class="fab fa-twitter"></i></a>
						<a href ="#"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
</footer>

<footer class="footer" id="footer"> 
	<div class="container">
		<div class="row">
		</div>
	</div>
</footer>
	<div class="footerBotton">
		<p>Copyright &copy;2024; Designed by <span class="designer">De Jesus</span></p>
	</div>

</body>
</html>