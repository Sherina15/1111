<?php
	session_start();

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "details_inventory_management";

	$connection = new mysqli($servername, $username, $password, $dbname);

	if($connection->connect_error)
	{
		die("Connection Failed: " . $connection->connect_error);
	}


	if(isset($_POST['save_data']))
	{
		$product_name = $_POST['product_name'];
		$category = $_POST['category'];
		$quantity = $_POST['quantity'];
		$price = $_POST['price'];
		
			$insert_query = "INSERT INTO product_management (product_name, category, quantity, price) 
					         VALUES ('$product_name', '$category', '$quantity', '$price')";

			$insert_query_run = mysqli_query($connection, $insert_query);

			if ($insert_query_run)
			{
				$_SESSION['status'] = "Product added successfully.";
				header('Location: dashboard.php?page=product_list');
			}
			else
			{
				$_SESSION['status'] = "Product insertation failed.";
				header('Location: dashboard.php?page=product_list');
			}
	}

	if(isset($_POST['click_view_btn'])){
		$id =$_POST['product_id'];

		
		$fetch_query = "SELECT * FROM product_management WHERE id ='$id'";
		$fetch_query_run = mysqli_query($connection, $fetch_query);

			if(mysqli_num_rows($fetch_query_run) > 0)
			{
				while($row = mysqli_fetch_array($fetch_query_run))
				{
					echo '
						<h6>ID: ' .$row['id']. '</h6>
						<h6>Product Name: ' .$row['product_name']. '</h6>
						<h6>Category: ' .$row['Category']. '</h6>
						<h6>Quantity: ' .$row['quantity']. '</h6>
						<h6>Price: ' .$row['price']. '</h6>
						<h6>Date Added: ' .$row['date_added']. '</h6>

						';
				}
			}
			else
			{
			
			

				echo '<h4> No record found </h4>';


			}



	}








if(isset($_POST['click_edit_btn'])){
		$id =$_POST['product_id'];
		$arrayResult =[];
		
		$fetch_query = "SELECT * FROM product_management WHERE id ='$id'";
		$fetch_query_run = mysqli_query($connection, $fetch_query);

			if(mysqli_num_rows($fetch_query_run) > 0)
			{
				while($row = mysqli_fetch_array($fetch_query_run))
				{
					array_push($arrayResult, $row);
					header('content-type: application/json');
					echo json_encode($arrayResult);
				}
			}
			else
			{
			
			

				echo '<h4> No record found </h4>';


			}



	}




if (isset($_POST['update_product'])) {
    $id = $_POST['id'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $date = $_POST['date'];
   

    $servername = "localhost";
    $dbUsername = "root"; // Renamed to avoid conflict with $username
    $password = "";
    $dbname = "details_inventory_management";

    $connection = new mysqli($servername, $dbUsername, $password, $dbname);

    if ($connection->connect_error) {
        die("Connection Failed: " . $connection->connect_error);
    }

    // Check for existing username, excluding the current user's username
   
        // Proceed with the update
        $update_query = "UPDATE product_management SET quantity = '$quantity', price = '$price' WHERE id = $id";

        if ($connection->query($update_query) === TRUE) {
            $_SESSION['status'] = "Data updated successfully.";
            header('Location: dashboard.php?page=product_list');
            exit; // Important to prevent further execution
        } else {
            $_SESSION['status'] = "Data update failed: " . $connection->error; // Added error message
            header('Location: dashboard.php?page=product_list');
            exit; // Important to prevent further execution
        }
    

    $connection->close(); // Close the database connection
}


if (isset($_POST['click_delete_btn'])){
	

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "inventory_management";

	$connection = new mysqli($servername, $username, $password, $dbname);


	$id = $_POST['account_id'];
	$delete_query = "DELETE FROM product_management WHERE id = '$id'";
	$delete_query_run = mysqli_query($connection,$delete_query);


	if($delete_query_run)
		{
				$_SESSION['status'] = "Data update successfully.";
				header('Location: dashboard.php?page=product_list');
			}
			else
			{
				$_SESSION['status'] = "Data  update failed.";
				header('Location: dashboard.php?page=product_list');
			}

}





?>

